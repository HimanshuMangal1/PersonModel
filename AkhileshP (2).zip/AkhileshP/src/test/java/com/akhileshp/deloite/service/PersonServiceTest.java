package com.akhileshp.deloite.service;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockitoSession;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import com.akhileshp.deloite.entity.Person;

@RunWith(SpringRunner.class)
public class PersonServiceTest {

	@InjectMocks
	PersonService personService;

	

	@Mock
	List<Person> persons;
	@Mock
	Map<Integer, List<Person>> map;

	@Before
	public void setUp() {
		
		persons = new ArrayList<>();
		persons.add(new Person(1, "p1", "11", 1));
		persons.add(new Person(2, "p2", "11", 2));
		persons.add(new Person(3, "p3", "11", 3));
		persons.add(new Person(4, "p4", "11", 4));
		persons.add(new Person(5, "p5", "11", 5));
		persons.add(new Person(6, "p6", "11", 6));
		persons.add(new Person(7, "p7", "11", 7));
		persons.add(new Person(8, "p8", "11", 8));
		persons.add(new Person(9, "p9", "11", 9));
		persons.add(new Person(10, "p10", "11", 10));
		persons.add(new Person(11, "p11", "11", 10));
		persons.add(new Person(11, "p12", "11", 10));

		persons.add(new Person(18, "p18", "11", 13));
		persons.add(new Person(19, "p19", "11", 14));
		persons.add(new Person(20, "p20", "11", 15));
		persons.add(new Person(21, "p21", "11", 16));
		persons.add(new Person(22, "p22", "11", 17));
		persons.add(new Person(23, "p23", "11", 18));
		persons.add(new Person(24, "p24", "11", 19));
		persons.add(new Person(25, "p25", "11", 20));
		persons.add(new Person(26, "p26", "11", 20));
		persons.add(new Person(27, "p27", "11", 20));
		persons.add(new Person(28, "p28", "11", 20));
		persons.add(new Person(29, "p29", "11", 20));
		persons.add(new Person(30, "p30", "11", 20));
		persons.add(new Person(31, "p31", "11", 21));

		persons.add(new Person(13, "p13", "11", 10));
		persons.add(new Person(14, "p14", "11", 10));
		persons.add(new Person(15, "p15", "11", 10));
		persons.add(new Person(16, "p16", "11", 11));
		persons.add(new Person(17, "p17", "11", 12));

		persons.add(new Person(32, "p32", "11", 22));
		persons.add(new Person(33, "p33", "11", 23));
		persons.add(new Person(34, "p34", "11", 24));
		persons.add(new Person(35, "p35", "11", 25));
		persons.add(new Person(36, "p36", "11", 26));

		persons.add(new Person(37, "p37", "11", 27));
		persons.add(new Person(38, "p38", "11", 28));
		persons.add(new Person(39, "p39", "11", 29));
		persons.add(new Person(40, "p40", "11", 30));
	}

	@Test
	public void getPersonsByGroupTest() {

		personService.getPersonsByGroup(persons);

	}

	@Test
	public void sortPersonsByStreamTest() {
		
		Collections c= Mockito.mock(Collections.class);
		 map = new HashMap<>();
		List<Person> person_10 = new ArrayList<>();
		person_10.add(new Person(13, "p13", "11", 10));
		person_10.add(new Person(14, "p14", "11", 10));
		List<Person> person_20 = new ArrayList<>();

		person_20.add(new Person(24, "p24", "11", 19));
		person_20.add(new Person(25, "p25", "11", 20));
		person_20.add(new Person(26, "p26", "11", 20));

		map.put(10, person_10);
		map.put(20, person_20);

		personService.sortPersonsByStream(map);
	}

	 @Test
	public void sortPersonsByComparatorTest() {
		 Map<Integer, List<Person>> map = new HashMap<>();
			List<Person> person_10 = new ArrayList<>();
			person_10.add(new Person(13, "p13", "11", 10));
			person_10.add(new Person(14, "p14", "11", 10));
			List<Person> person_20 = new ArrayList<>();

			person_20.add(new Person(24, "p24", "11", 19));
			person_20.add(new Person(25, "p25", "11", 20));
			person_20.add(new Person(26, "p26", "11", 20));

			map.put(10, person_10);
			map.put(20, person_20);

		 personService.sortPersonsByComparator(map);
	}
	 
	 @Test
		public void sortPersonsByComparableTest() {
			 Map<Integer, List<Person>> map = new HashMap<>();
				List<Person> person_10 = new ArrayList<>();
				person_10.add(new Person(13, "p13", "11", 10));
				person_10.add(new Person(14, "p14", "11", 10));
				List<Person> person_20 = new ArrayList<>();

				person_20.add(new Person(24, "p24", "11", 19));
				person_20.add(new Person(25, "p25", "11", 20));
				person_20.add(new Person(26, "p26", "11", 20));

				map.put(10, person_10);
				map.put(20, person_20);

			 personService.sortPersonsByComparable(map);
		}
}
