package com.akhileshp.deloite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AkhileshPApplication {

	public static void main(String[] args) {
		SpringApplication.run(AkhileshPApplication.class, args);
	}

}
