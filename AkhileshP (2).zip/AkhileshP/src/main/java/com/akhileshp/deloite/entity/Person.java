package com.akhileshp.deloite.entity;

import lombok.Data;


public class Person  implements Comparable<Person>{
	private int id;
	private String name;
	private String contact;
	private int age;
	
	
	
	public Person() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Person(int id, String name, String contact, int age) {
		super();
		this.id = id;
		this.name = name;
		this.contact = contact;
		this.age = age;
	}


	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}


	@Override
	public String toString() {
		return "Person [id=" + id + ", name=" + name + ", contact=" + contact + ", age=" + age + "]";
	}


	@Override
	public int compareTo(Person o) {
		// TODO Auto-generated method stub
		
		if(age==o.age)  
			return 0;  
			else if(age>o.age)  
			return 1;  
			else  
			return -1;  
			
	}
	
	
	
	
	

}
