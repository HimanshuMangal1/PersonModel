package com.akhileshp.deloite.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import com.akhileshp.deloite.entity.Person;

public class PersonController {
	
	public static List<Person> dummyData(){
		List<Person> persons = new ArrayList<>();
		persons.add(new Person(1, "p1", "11", 1));
		persons.add(new Person(2, "p2", "11", 2));
		persons.add(new Person(3, "p3", "11", 3));
		persons.add(new Person(4, "p4", "11", 4));
		persons.add(new Person(5, "p5", "11", 5));
		persons.add(new Person(6, "p6", "11", 6));
		persons.add(new Person(7, "p7", "11", 7));
		persons.add(new Person(8, "p8", "11", 8));
		persons.add(new Person(9, "p9", "11", 9));
		persons.add(new Person(10, "p10", "11", 10));
		persons.add(new Person(11, "p11", "11", 10));
		persons.add(new Person(11, "p12", "11", 10));
	
		persons.add(new Person(18, "p18", "11", 13));
		persons.add(new Person(19, "p19", "11", 14));
		persons.add(new Person(20, "p20", "11", 15));
		persons.add(new Person(21, "p21", "11", 16));
		persons.add(new Person(22, "p22", "11", 17));
		persons.add(new Person(23, "p23", "11", 18));
		persons.add(new Person(24, "p24", "11", 19));
		persons.add(new Person(25, "p25", "11", 20));
		persons.add(new Person(26, "p26", "11", 20));
		persons.add(new Person(27, "p27", "11", 20));
		persons.add(new Person(28, "p28", "11", 20));
		persons.add(new Person(29, "p29", "11", 20));
		persons.add(new Person(30, "p30", "11", 20));
		persons.add(new Person(31, "p31", "11", 21));
		
		persons.add(new Person(13, "p13", "11", 10));
		persons.add(new Person(14, "p14", "11", 10));
		persons.add(new Person(15, "p15", "11", 10));
		persons.add(new Person(16, "p16", "11", 11));
		persons.add(new Person(17, "p17", "11", 12));
		
		persons.add(new Person(32, "p32", "11", 22));
		persons.add(new Person(33, "p33", "11", 23));
		persons.add(new Person(34, "p34", "11", 24));
		persons.add(new Person(35, "p35", "11", 25));
		persons.add(new Person(36, "p36", "11", 26));
		
		persons.add(new Person(37, "p37", "11", 27));
		persons.add(new Person(38, "p38", "11", 28));
		persons.add(new Person(39, "p39", "11", 29));
		persons.add(new Person(40, "p40", "11", 30));
		
		
			
			
			return persons;
			
	}
	
	
public Map<Integer, List<Person>> getPersonsGroup(List<Person> persons){
	
	System.out.println(persons);
	
	System.out.println("=========================");
	Map<Integer, List<Person>> map= new HashMap<>();
	
	
	map.put(10, persons.stream().filter(p->p.getAge()<=10).collect(Collectors.toList()));
	map.put(20, persons.stream().filter(p->(p.getAge()>10&& p.getAge()<=20)).collect(Collectors.toList()));
	map.put(30, persons.stream().filter(p->p.getAge()>20).collect(Collectors.toList()));
	
	System.out.println(map);
		
		
		return map;
		
	}

public static void main(String[] args) {
	List<Person> persons = dummyData();
	PersonController pc= new PersonController();
	Map<Integer, List<Person>> map=pc.getPersonsGroup(persons);
	
	
	
	System.out.println("===============personGroup End Here==============");
	
	List<Person> person_10	= map.get(10).stream().distinct().sorted((a,b)->(a.getAge()>b.getAge() ? 1:a.getAge()<b.getAge() ? -1:0)).collect(Collectors.toList());
	System.out.println(person_10);
	System.out.println("===============sorting 10th group  End  Here==============");
	List<Person> person_20	= map.get(20).stream().distinct().sorted((a,b)->(a.getAge()>b.getAge() ? 1:a.getAge()<b.getAge() ? -1:0)).collect(Collectors.toList());
	System.out.println(person_20);
	
	System.out.println("===============sorting 20th group  End  Here==============");
	
	List<Person> person_10_cptr=map.get(10);
	
	Collections.sort(person_10_cptr,  (a,b)->(a.getAge()>b.getAge() ? 1:a.getAge()<b.getAge() ? -1:0)); 
	System.out.println(person_10_cptr);
	
	System.out.println("===============comparable Here==============");
	List<Person> ppp=map.get(20);
	Collections.sort(ppp);
	
	System.out.println(ppp);
	
	System.out.println("===============ForEach Start  Here==============");
	
	Map<Integer, List<Person>> mapFor=pc.getPersonsGroup(persons);
	
	List<Person> p_10=mapFor.get(10);
	//List<Person> p_20=mapFor.get(20);
	p_10.sort((a,b)->(a.getAge()<b.getAge() ? 1:a.getAge()>b.getAge() ? -1:0));
	System.out.println("Himanshu ForEach starting ==>  {}"+ p_10);
	
//	p_10.forEach(p1->{
//		p_10.forEach(p2->{
//			if(p1.getAge()>p2.getAge()) {
////				Person temp=p1;
////				p1=p2;
////				p2=temp;
//				
//				p2=p1;
//				//p1=p2;
//			}
//		});
//	});
	
	for (Person p1 : p_10) {
		for (Person p2 : p_10) {
			if (p1.getAge() > p2.getAge()) {
			int p1_index=	p_10.indexOf(p1);
			int p2_index=	p_10.indexOf(p2);
			
//			Person temp1 = p1;
//			Person temp2 = p2;
			p_10.add(p1_index, p2);
			p_10.add(p2_index, p1);
			

			}
		}
	}
	
	System.out.println("Himanshu ForEach ==>  {}"+ p_10);
	
	
	System.out.println("===============ForEach  END Here==============");
	
	
	
}
}
