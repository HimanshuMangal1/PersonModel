package com.akhileshp.deloite.service;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.akhileshp.deloite.entity.Person;

public class PersonService {

	public Map<Integer, List<Person>> getPersonsByGroup(List<Person> persons) {

		Map<Integer, List<Person>> map = new HashMap<>();

		map.put(10, persons.stream().filter(p -> p.getAge() <= 10).collect(Collectors.toList()));
		map.put(20, persons.stream().filter(p -> (p.getAge() > 10 && p.getAge() <= 20)).collect(Collectors.toList()));
		// map.put(30, persons.stream().filter(p -> p.getAge() >
		// 20).collect(Collectors.toList()));

		return map;

	}

	public Map<Integer, List<Person>> sortPersonsByStream(Map<Integer, List<Person>> map) {

		if (!map.isEmpty()) {

			List<Person> person_10 = map.get(10).stream().distinct().sorted((a, b) -> (a.getAge() > b.getAge() ? 1 : a.getAge() < b.getAge() ? -1 : 0)).collect(Collectors.toList());
			map.put(10, person_10);

			List<Person> person_20 = map.get(20).stream().distinct().sorted((a, b) -> (a.getAge() > b.getAge() ? 1 : a.getAge() < b.getAge() ? -1 : 0)).collect(Collectors.toList());

			map.put(20, person_20);

		}
		return map;

	}

	public Map<Integer, List<Person>> sortPersonsByComparator(Map<Integer, List<Person>> map) {

		if (!map.isEmpty()) {

			List<Person> person_10_cptr = map.get(10);
			List<Person> person_20 = map.get(20);

			Collections.sort(person_10_cptr,(a, b) -> (a.getAge() > b.getAge() ? 1 : a.getAge() < b.getAge() ? -1 : 0));

			Collections.sort(person_20, (a, b) -> (a.getAge() > b.getAge() ? 1 : a.getAge() < b.getAge() ? -1 : 0));

			map.put(10, person_10_cptr);
			map.put(20, person_20);

		}
		return map;

	}

	public Map<Integer, List<Person>> sortPersonsByComparable(Map<Integer, List<Person>> map) {

		if (!map.isEmpty()) {

			List<Person> person_10_cptr = map.get(10);
			List<Person> person_20 = map.get(20);

			Collections.sort(person_10_cptr);

			Collections.sort(person_20);

			map.put(10, person_10_cptr);
			map.put(20, person_20);

		}
		return map;

	}

}
